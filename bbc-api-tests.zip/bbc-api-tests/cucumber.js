export default {
  default: `--publish-quiet --require features/step_definitions/**/*.js --require util/world.js --require util/report.js --format json:report/cucumber_report.json`
};